<?php
session_start();
session_unset();
session_destroy();
?>
<html>
<head>
<title>Session Cache Destroy Page</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<center>
<b>Session Cache Destroyed</b>
</body>
</html>
