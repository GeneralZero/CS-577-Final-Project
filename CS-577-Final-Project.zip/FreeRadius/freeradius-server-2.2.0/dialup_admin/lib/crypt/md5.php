<?php
function da_encrypt($passwd)
{
        return md5($passwd);
}
?>
